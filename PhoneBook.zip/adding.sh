#!/bin/sh
#this particular script can be used for entry purpose 


#phone book name

PHONEBOOK="PhoneBook.txt"

#Assigns varaible for NAME and asking user to enter NAME

echo -n"Person's Name:"

read PerName

#Assigns varaible for ADDRESS and asking user to enter ADDRESS

echo -n"Person's Address:"

read PerAddress

#Assigns varaible for NAME and asking user to enter NAME

echo -n"Person's Number:"

read PerNumber

echo "enter values:"

echo "$PerName;$PerAddress;$PerNumber "

echo -n "y/n:"

read PerAnswer

if (PerAnswer=="y")

then

           #Writing VALUES to Phone BOOK

            echo "$PerName;$PerAddress;$PerNumber">>PHONEBOOK;
	
	else

            #Message FOR User

            echo "$PerName;$PerAddress;$PerNumber" #NOT Included to book

fi


