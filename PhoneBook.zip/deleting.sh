






#!/bin/sh


#phone book name

PHONEBOOK="PhoneBook.txt"

#ASK user to delete a specific line

echo -n"Which LINE wants to delete"

read numb

#RENAME before DELETE

mv $PHONEBOOK PhoneBook.txt

#ADDING line_NUMBers and again deleting number

nl --numb-separator=":"PhoneBook.txt|grep -v $numb:|awk -F:'{print $2}'


