


#!/bin/sh
        

#phone book name

PHONEBOOK="PhoneBook.txt"

#Ask the USER to looking for

echo -n "Which PERSON you need to Find:"

read Perfind

#Printing HEADER before the Ans

grep -i $PerFind $PHONEBOOK
