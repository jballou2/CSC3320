

#phone book name

PHONEBOOK="PhoneBook.txt"

#NUMBER format before the data

echo"Line Number: Name; Address;phone number"

#Listing In alphabetical order

Sort PHONEBOOK

#Printing the PhoneBook with LINE numbera and less paused

n1- -numb-separator=":    "$PHONEBOOK |less
